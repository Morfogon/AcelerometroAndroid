package com.example.atividade5b;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.atividade5b.R;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private EditText alta;
    private EditText media;
    private EditText baixa;  // variáveis
    private EditText altay;
    private EditText mediay;
    private EditText baixay;  // variáveis
    private EditText telefone;
    private TextView medido;
    private TextView medidoy;
    private Button iniciar;
    private Button parar;
    private int estado;
    private SensorManager acelerometro;
    private double ax;
    private double ay;
    private String aux;
    private String auy;
    private String numero;
    private double refA;
    private double refM;
    private double refB;
    private double refAy;
    private double refMy;
    private double refBy;
    private SmsManager sm;
    private int contador;
    private Context context;
    private TextView aviso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela1);

        context=MainActivity.this;   // obtendo dados da activity

        // vinculando com os componentes da tela

        telefone=findViewById(R.id.telefone);
        alta=findViewById(R.id.alta);
        media=findViewById(R.id.media);
        baixa=findViewById(R.id.baixa);
        altay=findViewById(R.id.altay);
        mediay=findViewById(R.id.mediay);
        baixay=findViewById(R.id.baixay);
        iniciar=findViewById(R.id.iniciar);
        parar=findViewById(R.id.parar);
        medido=findViewById(R.id.medido);
        medidoy=findViewById(R.id.medidoy);
        aviso=findViewById(R.id.aviso);

        // valores iniciais das variáveis

        estado=0;
        contador=0;

        // preparando o sensor de aceleração

        // configurando o acesso ao sensor de aceleração
        acelerometro=(SensorManager) getSystemService(SENSOR_SERVICE);
        acelerometro.registerListener(this, acelerometro.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);

        // preparando o uso do SMS
        sm=SmsManager.getDefault();

        // eventos dos botões

        iniciar.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                estado=1;                               // iniciar monitoração
                numero=telefone.getText().toString();   // obtendo o número de telefone
                refA=Math.abs(Double.valueOf(alta.getText().toString())); // obtendo a aceleração de refêrência
                refM=Math.abs(Double.valueOf(media.getText().toString()));
                refB=Math.abs(Double.valueOf(baixa.getText().toString()));
                refAy=Math.abs(Double.valueOf(altay.getText().toString())); // obtendo a aceleração de refêrência
                refMy=Math.abs(Double.valueOf(mediay.getText().toString()));
                refBy=Math.abs(Double.valueOf(baixay.getText().toString()));
                aviso.setText("Alarme ligado: 10seg");   // avisa que o alarme esta ligado
            }
        });

        parar.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                estado=0;   // parar monitoração
                aviso.setText("Alarme desligado");   // avisa que o alarme esta desligado
            }
        });

        process();   // iniciando a Thread
    }

    // rotina que é executada quando houver mudança na precisão do sensor
    @Override
    public void onAccuracyChanged(Sensor sensor, int i)
    {

    }

    // rotina que é executada quando houver mudança na aceleração
    @Override
    public void onSensorChanged(SensorEvent sensorEvent)
    {
        if (sensorEvent.sensor.getType()==Sensor.TYPE_ACCELEROMETER)
        {
            ax=Math.abs(sensorEvent.values[0]);  // lendo a aceleração em x
            ay=Math.abs(sensorEvent.values[1]);  // lendo a aceleração em y
            aux="ax medido= "+String.valueOf(ax)+" m/s^2";
            auy="ay medido= "+String.valueOf(ay)+" m/s^2";
            medido.setText(aux);
            medidoy.setText(auy);// exibindo a aceleração
            if (estado==1)             // se a monitoração foi habilitada
            {
                if ((ax>=refB && ax < refM) || (ay>=refBy && ay < refMy))// se passou da aceleração limite
                {
                    if (contador == 0) // se o contador for 0
                    {
                        // se a aceleração for maior que a referência
                        // envia mensagem de SMS
                        //sm.sendTextMessage(numero, null, "Alarme", null, null);
                        contador = 10;   // carrega o contador com 60 (para enviar SMS a cada 1 minuto)
                        // contador é decrementado na Thread a cada 1 segundo
                        Toast.makeText(context, "Aceleração baixa", Toast.LENGTH_SHORT).show(); // exibe menssagem
                    }
                }

                if ((ax>=refM && ax < refA) || (ay>=refMy && ay < refAy)) // se passou da aceleração limite
                {
                    if (contador == 0) // se o contador for 0
                    {
                        contador = 10;   // carrega o contador com 60 (para enviar SMS a cada 1 minuto)
                        Toast.makeText(context, "Aceleração Media", Toast.LENGTH_SHORT).show(); // exibe menssagem
                    }
                }

                        if (ax>=refA || ay>=refAy) // se passou da aceleração limite
                        {
                            if (contador == 0) // se o contador for 0
                            {
                                contador = 10;   // carrega o contador com 60 (para enviar SMS a cada 1 minuto)
                                Toast.makeText(context,"Aceleração Alta",Toast.LENGTH_SHORT).show(); // exibe menssagem
                            }

                }
            }
        }
    }



    private void process()   // Thread
    {
        Thread proc = new Thread(new Runnable()
        {
            @Override
            public void run()
            {
                try
                {
                    while (true)   // loop infinito
                    {
                        Thread.sleep(1000);   // processo espera 1000ms
                        runOnUiThread(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                if (contador>0)  // se o contador passou de 0
                                {
                                    contador--;    // decrementa o contador
                                    aux="Alarme ligado: "+String.valueOf(contador)+"seg";
                                    aviso.setText(aux);  // mostra o valor da temporização
                                }
                            }
                        });
                    }
                }
                catch (Exception e)
                {
                }
            }
        });
        proc.start();   // iniciar a Thread

    }

}